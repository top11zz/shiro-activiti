package com.ms.service;

import com.ms.entity.Leavebill;
import com.baomidou.mybatisplus.extension.service.IService;

/**
 * <p>
 *  服务类
 * </p>
 *
 * @author xiedong
 * @since 2019-11-06
 */
public interface ILeavebillService extends IService<Leavebill> {

}
