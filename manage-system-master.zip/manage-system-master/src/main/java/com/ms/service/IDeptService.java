package com.ms.service;

import com.ms.entity.Dept;
import com.baomidou.mybatisplus.extension.service.IService;

/**
 * <p>
 *  服务类
 * </p>
 *
 * @author xiedong
 * @since 2019-11-05
 */
public interface IDeptService extends IService<Dept> {

}
