package com.ms.mapper;

import com.ms.entity.Leavebill;
import com.baomidou.mybatisplus.core.mapper.BaseMapper;

/**
 * <p>
 *  Mapper 接口
 * </p>
 *
 * @author xiedong
 * @since 2019-11-06
 */
public interface LeavebillMapper extends BaseMapper<Leavebill> {

}
