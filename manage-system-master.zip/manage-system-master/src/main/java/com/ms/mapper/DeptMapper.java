package com.ms.mapper;

import com.ms.entity.Dept;
import com.baomidou.mybatisplus.core.mapper.BaseMapper;

/**
 * <p>
 *  Mapper 接口
 * </p>
 *
 * @author xiedong
 * @since 2019-11-05
 */
public interface DeptMapper extends BaseMapper<Dept> {

}
